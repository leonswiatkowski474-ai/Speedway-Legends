// Składa katalogi www/ (Capacitor) i pwa/ (do wgrania na hosting) z pliku game.html + lokalnego three.js.
const fs = require('fs'), path = require('path');
const root = __dirname;
const three = path.join(root, 'node_modules', 'three', 'build', 'three.min.js');
if (!fs.existsSync(three)) { console.error('Brak three.js. Najpierw: npm install'); process.exit(1); }
const cdn = /<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/three\.js\/r128\/three\.min\.js"><\/script>/;
let html = fs.readFileSync(path.join(root, 'game.html'), 'utf8');
if (!cdn.test(html)) { console.error('Nie znaleziono znacznika three.js (CDN) w game.html'); process.exit(1); }
html = html.replace(cdn, '<script src="three.min.js"></script>');
function out(dir, transform) {
  const d = path.join(root, dir); fs.rmSync(d, { recursive: true, force: true }); fs.mkdirSync(d, { recursive: true });
  fs.writeFileSync(path.join(d, 'index.html'), transform ? transform(html) : html);
  fs.copyFileSync(three, path.join(d, 'three.min.js')); return d;
}
out('www');
const pwa = out('pwa', h => h.replace('</head>', '<link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icon-192.png"></head>').replace('</body>', "<script>if('serviceWorker' in navigator&&location.protocol.indexOf('http')===0)navigator.serviceWorker.register('sw.js')</script></body>"));
for (const f of ['manifest.webmanifest', 'sw.js']) fs.copyFileSync(path.join(root, 'pwa-template', f), path.join(pwa, f));
for (const f of ['icon-192.png', 'icon-512.png']) fs.copyFileSync(path.join(root, 'assets', f), path.join(pwa, f));
console.log('Gotowe: www/ (aplikacja Android) i pwa/ (do hostingu)');
