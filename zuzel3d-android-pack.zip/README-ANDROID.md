# Żużel 3D na telefon (Android) – plik APK bez instalowania czegokolwiek na komputerze

Nie mam w tym środowisku Android SDK ani internetu, więc nie mogę sam skompilować pliku APK. Ta paczka robi to za ciebie: GitHub zbuduje APK automatycznie.

## Sposób 1: APK przez GitHub (najprościej, ok. 10 minut)
1. Załóż darmowe konto na github.com i utwórz nowe repozytorium (może być prywatne).
2. Wgraj do niego CAŁĄ zawartość tej paczki (Add file → Upload files). Ważne, żeby powstał folder `.github/workflows/android.yml`. Jeśli przeglądarka nie wgra folderu z kropką, utwórz plik ręcznie: Add file → Create new file → nazwa `.github/workflows/android.yml` i wklej jego zawartość.
3. Zakładka Actions → „Build Android APK” → Run workflow. Czekaj 8-12 minut.
4. Wejdź w zakończone uruchomienie i pobierz artefakt `zuzel3d-apk` (zip z plikiem `app-debug.apk`).
5. Prześlij plik na telefon, otwórz go i zainstaluj (Android poprosi o zgodę na instalację z nieznanych źródeł).

Aplikacja: pełny ekran, zawsze poziomo, ekran się nie wygasza, działa offline, wibracje przy starcie i upadku.
To jest APK „debug” (podpisany kluczem testowym). Do Google Play potrzebny jest podpis wydaniowy.

## Sposób 2: PWA (iPhone i Android, bez APK)
Po `npm install && node build-www.js` powstaje folder `pwa/`. Wgraj go na dowolny hosting HTTPS (np. Netlify Drop albo GitHub Pages), otwórz adres na telefonie i wybierz „Dodaj do ekranu głównego”. Na iPhonie to jedyna droga (plik IPA wymaga komputera Mac i konta Apple Developer). Workflow GitHub zapisuje też gotowy folder `pwa` jako artefakt `zuzel3d-pwa`.

## Sposób 3: lokalnie
Wymagane: Node 20, JDK 17, Android SDK. `npm run android`, potem `cd android && ./gradlew assembleDebug`. APK: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Uwagi
- Nie testowałem budowania w tym środowisku. Jeśli Actions zgłosi błąd, wyślij mi log, a poprawię.
- W aplikacji nie ma Claude, więc wywiady menedżera używają uproszczonej analizy słów kluczowych.
- Zapisy gry leżą w pamięci aplikacji, odinstalowanie je kasuje.
- Gra to wersja bez marek i herbów, z lekko zmienionymi nazwiskami zawodników. Przed sprzedażą sprawdź prawa do nazw.
