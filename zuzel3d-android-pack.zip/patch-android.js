// Po "npx cap add android": orientacja pozioma, pełny ekran (immersive), ikony, ekran zawsze włączony.
const fs = require('fs'), path = require('path');
const A = path.join(__dirname, 'android', 'app', 'src', 'main');
function edit(f, fn) { const p = path.join(A, f); if (!fs.existsSync(p)) { console.warn('Brak', f); return; } fs.writeFileSync(p, fn(fs.readFileSync(p, 'utf8'))); }
edit('AndroidManifest.xml', x => {
  if (!/screenOrientation/.test(x)) x = x.replace('<activity', '<activity android:screenOrientation="sensorLandscape"');
  if (!/hardwareAccelerated/.test(x)) x = x.replace('<application', '<application android:hardwareAccelerated="true"');
  return x;
});
edit('res/values/styles.xml', x => x.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>'));
edit('res/values/ic_launcher_background.xml', x => x.replace(/#[0-9A-Fa-f]{6}/, '#0E1F3D'));
const java = path.join(A, 'java', 'pl', 'zuzel3d', 'game', 'MainActivity.java');
fs.mkdirSync(path.dirname(java), { recursive: true });
fs.writeFileSync(java, `package pl.zuzel3d.game;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); hide(); }
  @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hide(); }
  private void hide() {
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    c.hide(WindowInsetsCompat.Type.systemBars());
    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
  }
}
`);
const src = path.join(__dirname, 'assets', 'android');
for (const d of fs.readdirSync(src)) {
  const dst = path.join(A, 'res', d); fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(path.join(src, d))) fs.copyFileSync(path.join(src, d, f), path.join(dst, f));
}
console.log('Android: spatchowane');
